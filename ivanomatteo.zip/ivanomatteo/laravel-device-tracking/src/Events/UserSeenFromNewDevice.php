<?php

namespace IvanoMatteo\LaravelDeviceTracking\Events;

class UserSeenFromNewDevice extends UserSeenFromUnverifiedDevice
{
}
