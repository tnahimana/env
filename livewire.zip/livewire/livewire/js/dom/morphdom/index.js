import morphAttrs from './morphAttrs';
import morphdomFactory from './morphdom';

var morphdom = morphdomFactory(morphAttrs);

export default morphdom;